from django.shortcuts import render

def accounts(request):
    return render(request, "accounts.html")

def login(request):
    pass

def logout(request):
    pass

def register(request):
    pass
